"""
database.py - SQLite setup for StudyPilot AI.

Tables
  settings : one row with the student's profile + study preferences
  subjects : name, difficulty (Easy/Medium/Hard), exam date
  topics   : chapters/topics that belong to a subject (done = 0 or 1)
  sessions : timetable entries (study sessions and breaks)
"""
import os
import random
import sqlite3
from datetime import date, timedelta

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "studypilot.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    name TEXT NOT NULL,
    course TEXT NOT NULL DEFAULT '',
    daily_hours REAL NOT NULL DEFAULT 4,
    preferred_time TEXT NOT NULL DEFAULT 'evening',
    session_minutes INTEGER NOT NULL DEFAULT 50,
    break_minutes INTEGER NOT NULL DEFAULT 10
);
CREATE TABLE IF NOT EXISTS subjects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    difficulty TEXT NOT NULL CHECK (difficulty IN ('Easy','Medium','Hard')),
    exam_date TEXT NOT NULL,
    pending_override INTEGER            -- set by the planner form, NULL = count topics
);
CREATE TABLE IF NOT EXISTS topics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    done INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subject_id INTEGER REFERENCES subjects(id) ON DELETE CASCADE,
    topic_id INTEGER REFERENCES topics(id) ON DELETE SET NULL,
    topic TEXT NOT NULL DEFAULT '',
    date TEXT NOT NULL,
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    minutes INTEGER NOT NULL,
    kind TEXT NOT NULL DEFAULT 'study',   -- 'study' or 'break'
    done INTEGER NOT NULL DEFAULT 0
);
"""

SAMPLE = [  # (subject, difficulty, days until exam, [(topic, done)])
    ("Data Structures", "Hard", 6, [("Arrays & linked lists", 1), ("Stacks & queues", 1), ("Trees", 0), ("Graphs", 0), ("Hashing", 0), ("Sorting algorithms", 0)]),
    ("Engineering Mathematics", "Hard", 9, [("Matrices", 1), ("Differential equations", 0), ("Laplace transforms", 0), ("Fourier series", 0), ("Probability", 0)]),
    ("Operating Systems", "Medium", 11, [("Processes & threads", 1), ("CPU scheduling", 1), ("Deadlocks", 0), ("Memory management", 0), ("File systems", 0)]),
    ("Database Systems", "Medium", 17, [("ER modelling", 1), ("Relational algebra", 0), ("SQL queries", 0), ("Normalization", 0), ("Transactions", 0)]),
    ("Technical Communication", "Easy", 24, [("Report writing", 1), ("Presentations", 0), ("Email etiquette", 0)]),
]


def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """Create tables; insert sample data on first run. Returns True if seeded."""
    conn = connect()
    conn.executescript(SCHEMA)
    fresh = conn.execute("SELECT COUNT(*) FROM settings").fetchone()[0] == 0
    if fresh:
        seed(conn)
    conn.commit()
    conn.close()
    return fresh


def seed(conn):
    """Demo student, subjects, topics and a week of study history."""
    random.seed(7)
    today = date.today()
    conn.execute("INSERT INTO settings(id,name,course,daily_hours,preferred_time) "
                 "VALUES (1,'Aarav Sharma','B.E. Computer Science, Sem 4',4,'evening')")
    sub_ids = []
    for name, diff, days, topics in SAMPLE:
        cur = conn.execute("INSERT INTO subjects(name,difficulty,exam_date) VALUES (?,?,?)",
                           (name, diff, (today + timedelta(days=days)).isoformat()))
        sub_ids.append((cur.lastrowid, [t[0] for t in topics]))
        for title, done in topics:
            conn.execute("INSERT INTO topics(subject_id,title,done) VALUES (?,?,?)", (cur.lastrowid, title, done))
    # Past six days of finished sessions (feeds streaks and charts) + one missed session yesterday.
    for i in range(6, 0, -1):
        day = (today - timedelta(days=i)).isoformat()
        for k in range(random.randint(2, 4)):
            sid, titles = random.choice(sub_ids)
            h = 17 * 60 + k * 60
            conn.execute("INSERT INTO sessions(subject_id,topic,date,start_time,end_time,minutes,done) VALUES (?,?,?,?,?,50,1)",
                         (sid, random.choice(titles), day, f"{h//60:02d}:{h%60:02d}", f"{(h+50)//60:02d}:{(h+50)%60:02d}"))
    sid, titles = sub_ids[0]
    conn.execute("INSERT INTO sessions(subject_id,topic,date,start_time,end_time,minutes,done) VALUES (?,?,?,'21:00','21:50',50,0)",
                 (sid, titles[2], (today - timedelta(days=1)).isoformat()))

"""
app.py - Flask backend for StudyPilot AI.
Serves one HTML page and a JSON API (/api/...) used by static/js/app.js.
Run with:  python app.py
"""
import re
from datetime import date, timedelta

from flask import Flask, g, jsonify, render_template, request

import database
import scheduler

app = Flask(__name__)


# ---------- small database helpers ----------
def db():
    if "db" not in g:
        g.db = database.connect()
    return g.db


@app.teardown_appcontext
def close_db(_):
    conn = g.pop("db", None)
    if conn:
        conn.close()


def rows(sql, args=()):
    return [dict(r) for r in db().execute(sql, args).fetchall()]


def one(sql, args=()):
    r = db().execute(sql, args).fetchone()
    return dict(r) if r else None


@app.errorhandler(ValueError)
def bad_input(e):
    return jsonify(error=str(e)), 400


# ---------- validation helpers (raise ValueError with a friendly message) ----------
def valid_date(v):
    try:
        return date.fromisoformat(str(v)).isoformat()
    except ValueError:
        raise ValueError("Enter a valid date.")


def valid_time(v):
    if not re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", str(v or "")):
        raise ValueError("Enter a valid time (HH:MM).")
    return v


def valid_num(v, lo, hi, label):
    try:
        n = float(v)
    except (TypeError, ValueError):
        raise ValueError(f"{label} must be a number.")
    if not lo <= n <= hi:
        raise ValueError(f"{label} must be between {lo} and {hi}.")
    return n


def valid_text(v, label, maxlen=60):
    v = str(v or "").strip()
    if not v:
        raise ValueError(f"{label} is required.")
    return v[:maxlen]


def valid_difficulty(v):
    if v not in ("Easy", "Medium", "Hard"):
        raise ValueError("Difficulty must be Easy, Medium or Hard.")
    return v


# ---------- shared calculations ----------
def get_settings():
    return one("SELECT * FROM settings WHERE id=1")


def subject_stats():
    """Subjects with topics, progress %, pending count and days left."""
    subs = rows("SELECT * FROM subjects ORDER BY exam_date, id")
    for s in subs:
        s["topics"] = rows("SELECT * FROM topics WHERE subject_id=? ORDER BY id", (s["id"],))
        s["total"] = len(s["topics"])
        s["done"] = sum(t["done"] for t in s["topics"])
        s["pending"] = s["pending_override"] if s["pending_override"] is not None else s["total"] - s["done"]
        s["progress"] = round(100 * s["done"] / s["total"]) if s["total"] else 0
        s["days_left"] = (date.fromisoformat(s["exam_date"]) - date.today()).days
    return subs


def streak():
    done = {r["date"] for r in rows("SELECT DISTINCT date FROM sessions WHERE kind='study' AND done=1")}
    d, n = date.today(), 0
    if d.isoformat() not in done:
        d -= timedelta(days=1)
    while d.isoformat() in done:
        n += 1
        d -= timedelta(days=1)
    return n


def daily_minutes(days=7):
    """Done vs planned study minutes for the last `days` days (oldest first)."""
    out = []
    for i in range(days - 1, -1, -1):
        d = (date.today() - timedelta(days=i)).isoformat()
        r = one("SELECT COALESCE(SUM(CASE WHEN done=1 THEN minutes END),0) AS done, COALESCE(SUM(minutes),0) AS planned "
                "FROM sessions WHERE kind='study' AND date=?", (d,))
        out.append(dict(date=d, **r))
    return out


def regenerate(days=7):
    """Delete unfinished sessions from today onward and build a fresh plan."""
    settings, subs, today = get_settings(), subject_stats(), date.today()
    for s in subs:
        s["queue"] = [(t["id"], t["title"]) for t in s["topics"] if not t["done"]]
    finished = rows("SELECT minutes, end_time FROM sessions WHERE kind='study' AND done=1 AND date=?", (today.isoformat(),))
    earliest = max((scheduler.to_minutes(r["end_time"]) for r in finished), default=None)
    if earliest:
        earliest += settings["break_minutes"]
    plan = scheduler.generate_plan(subs, settings, today, days, sum(r["minutes"] for r in finished), earliest)
    c = db()
    c.execute("DELETE FROM sessions WHERE date>=? AND done=0", (today.isoformat(),))
    c.executemany("INSERT INTO sessions(subject_id,topic_id,topic,date,start_time,end_time,minutes,kind) "
                  "VALUES (:subject_id,:topic_id,:topic,:date,:start_time,:end_time,:minutes,:kind)", plan)
    c.commit()
    ranked = scheduler.rank_subjects(subs, today)
    return [dict(id=s["id"], name=s["name"], score=s["score"], difficulty=s["difficulty"],
                 days_left=s["days_left"], pending=s["pending"], progress=s["progress"]) for s in ranked], \
        sum(1 for p in plan if p["kind"] == "study")


# ---------- pages ----------
@app.get("/")
def index():
    return render_template("index.html")


# ---------- dashboard / progress / recommendations ----------
@app.get("/api/dashboard")
def dashboard():
    subs, today = subject_stats(), date.today().isoformat()
    total_topics = sum(s["total"] for s in subs)
    done_topics = sum(s["done"] for s in subs)
    stats = one("SELECT COALESCE(SUM(CASE WHEN done=1 THEN minutes END),0) AS mins, "
                "COUNT(CASE WHEN done=1 THEN 1 END) AS completed, "
                "COUNT(CASE WHEN done=0 AND date>=? THEN 1 END) AS pending "
                "FROM sessions WHERE kind='study'", (today,))
    return jsonify(
        name=get_settings()["name"],
        total_hours=round(stats["mins"] / 60, 1), completed=stats["completed"], pending=stats["pending"],
        progress=round(100 * done_topics / total_topics) if total_topics else 0,
        today=rows("SELECT s.*, sub.name AS subject_name FROM sessions s LEFT JOIN subjects sub ON sub.id=s.subject_id "
                   "WHERE date=? ORDER BY start_time", (today,)),
        exams=[dict(name=s["name"], exam_date=s["exam_date"], days_left=s["days_left"], progress=s["progress"],
                    difficulty=s["difficulty"]) for s in subs if s["days_left"] >= 0],
        weekly=daily_minutes(7))


@app.get("/api/progress")
def progress():
    subs, today = subject_stats(), date.today()
    monday = (today - timedelta(days=today.weekday())).isoformat()
    week = one("SELECT COALESCE(SUM(minutes),0) AS m FROM sessions WHERE kind='study' AND done=1 AND date>=?", (monday,))["m"]
    day = one("SELECT COALESCE(SUM(minutes),0) AS m FROM sessions WHERE kind='study' AND done=1 AND date=?", (today.isoformat(),))["m"]
    return jsonify(today_hours=round(day / 60, 1), week_hours=round(week / 60, 1), streak=streak(),
                   topics_done=sum(s["done"] for s in subs), topics_total=sum(s["total"] for s in subs),
                   daily=daily_minutes(7),
                   subjects=[dict(name=s["name"], progress=s["progress"], done=s["done"], total=s["total"]) for s in subs])


@app.get("/api/recommendations")
def recommendations():
    today = date.today().isoformat()
    missed = one("SELECT COUNT(*) AS n FROM sessions WHERE kind='study' AND done=0 AND date<?", (today,))["n"]
    done_min = one("SELECT COALESCE(SUM(minutes),0) AS m FROM sessions WHERE kind='study' AND done=1 AND date=?", (today,))["m"]
    return jsonify(scheduler.recommend(subject_stats(), date.today(), streak(), missed, done_min, get_settings()))


# ---------- subjects & topics ----------
@app.get("/api/subjects")
def list_subjects():
    return jsonify(subject_stats())


@app.post("/api/subjects")
def add_subject():
    d = request.get_json(force=True)
    name = valid_text(d.get("name"), "Subject name")
    if one("SELECT id FROM subjects WHERE LOWER(name)=LOWER(?)", (name,)):
        raise ValueError("That subject already exists.")
    exam = valid_date(d.get("exam_date"))
    if exam <= date.today().isoformat():
        raise ValueError("Exam date must be in the future.")
    db().execute("INSERT INTO subjects(name,difficulty,exam_date) VALUES (?,?,?)", (name, valid_difficulty(d.get("difficulty")), exam))
    db().commit()
    return jsonify(ok=True), 201


@app.delete("/api/subjects/<int:sid>")
def delete_subject(sid):
    db().execute("DELETE FROM subjects WHERE id=?", (sid,))
    db().commit()
    return jsonify(ok=True)


@app.post("/api/subjects/<int:sid>/topics")
def add_topic(sid):
    title = valid_text(request.get_json(force=True).get("title"), "Topic", 80)
    if not one("SELECT id FROM subjects WHERE id=?", (sid,)):
        raise ValueError("Subject not found.")
    db().execute("INSERT INTO topics(subject_id,title) VALUES (?,?)", (sid, title))
    db().execute("UPDATE subjects SET pending_override=NULL WHERE id=?", (sid,))
    db().commit()
    return jsonify(ok=True), 201


@app.patch("/api/topics/<int:tid>")
def toggle_topic(tid):
    done = 1 if request.get_json(force=True).get("done") else 0
    t = one("SELECT subject_id FROM topics WHERE id=?", (tid,))
    if not t:
        raise ValueError("Topic not found.")
    db().execute("UPDATE topics SET done=? WHERE id=?", (done, tid))
    db().execute("UPDATE subjects SET pending_override=NULL WHERE id=?", (t["subject_id"],))
    db().commit()
    return jsonify(ok=True)


@app.delete("/api/topics/<int:tid>")
def delete_topic(tid):
    t = one("SELECT subject_id FROM topics WHERE id=?", (tid,))
    if t:
        db().execute("DELETE FROM topics WHERE id=?", (tid,))
        db().execute("UPDATE subjects SET pending_override=NULL WHERE id=?", (t["subject_id"],))
        db().commit()
    return jsonify(ok=True)


# ---------- AI planner ----------
@app.post("/api/planner")
def planner():
    d = request.get_json(force=True)
    hours = valid_num(d.get("hours"), 1, 12, "Study hours per day")
    pref = d.get("preferred")
    if pref not in scheduler.START_MINUTES:
        raise ValueError("Pick a preferred study time.")
    days = int(valid_num(d.get("days", 7), 1, 14, "Plan length"))
    items = d.get("subjects") or []
    if not items:
        raise ValueError("Add at least one subject first.")
    for it in items:
        sub = one("SELECT id FROM subjects WHERE id=?", (it.get("id"),))
        if not sub:
            raise ValueError("Unknown subject in form.")
        exam = valid_date(it.get("exam_date"))
        pending = int(valid_num(it.get("pending"), 0, 99, "Pending topics"))
        actual = one("SELECT COUNT(*) AS n FROM topics WHERE subject_id=? AND done=0", (sub["id"],))["n"]
        db().execute("UPDATE subjects SET difficulty=?, exam_date=?, pending_override=? WHERE id=?",
                     (valid_difficulty(it.get("difficulty")), exam, None if pending == actual else pending, sub["id"]))
    db().execute("UPDATE settings SET daily_hours=?, preferred_time=? WHERE id=1", (hours, pref))
    db().commit()
    ranking, count = regenerate(days)
    return jsonify(ranking=ranking, sessions=count, days=days)


@app.post("/api/regenerate")
def regen():
    ranking, count = regenerate(7)
    return jsonify(ranking=ranking, sessions=count)


# ---------- timetable sessions ----------
SESSION_SQL = ("SELECT s.*, sub.name AS subject_name FROM sessions s "
               "LEFT JOIN subjects sub ON sub.id=s.subject_id ")


@app.get("/api/sessions")
def list_sessions():
    start, end = valid_date(request.args.get("start")), valid_date(request.args.get("end"))
    return jsonify(rows(SESSION_SQL + "WHERE s.date BETWEEN ? AND ? ORDER BY s.date, s.start_time", (start, end)))


def end_time(start, minutes):
    total = scheduler.to_minutes(start) + minutes
    if total > 24 * 60:
        raise ValueError("A session cannot run past midnight.")
    return scheduler.to_hhmm(total)


@app.post("/api/sessions")
def add_session():
    d = request.get_json(force=True)
    if not one("SELECT id FROM subjects WHERE id=?", (d.get("subject_id"),)):
        raise ValueError("Pick a subject.")
    start, mins = valid_time(d.get("start_time")), int(valid_num(d.get("minutes"), 10, 240, "Length"))
    db().execute("INSERT INTO sessions(subject_id,topic,date,start_time,end_time,minutes) VALUES (?,?,?,?,?,?)",
                 (d["subject_id"], str(d.get("topic") or "Study session")[:80], valid_date(d.get("date")), start, end_time(start, mins), mins))
    db().commit()
    return jsonify(ok=True), 201


@app.patch("/api/sessions/<int:sid>")
def update_session(sid):
    cur, d = one("SELECT * FROM sessions WHERE id=?", (sid,)), request.get_json(force=True)
    if not cur:
        raise ValueError("Session not found.")
    if "done" in d:
        done = 1 if d["done"] else 0
        db().execute("UPDATE sessions SET done=? WHERE id=?", (done, sid))
        if cur["topic_id"]:                      # finishing a session completes its topic
            t = one("SELECT subject_id FROM topics WHERE id=?", (cur["topic_id"],))
            db().execute("UPDATE topics SET done=? WHERE id=?", (done, cur["topic_id"]))
            if t:
                db().execute("UPDATE subjects SET pending_override=NULL WHERE id=?", (t["subject_id"],))
    else:
        start = valid_time(d.get("start_time", cur["start_time"]))
        mins = int(valid_num(d.get("minutes", cur["minutes"]), 10, 240, "Length"))
        sub = d.get("subject_id", cur["subject_id"])
        if not one("SELECT id FROM subjects WHERE id=?", (sub,)):
            raise ValueError("Pick a subject.")
        db().execute("UPDATE sessions SET subject_id=?, topic=?, date=?, start_time=?, end_time=?, minutes=? WHERE id=?",
                     (sub, str(d.get("topic", cur["topic"]))[:80], valid_date(d.get("date", cur["date"])), start, end_time(start, mins), mins, sid))
    db().commit()
    return jsonify(ok=True)


@app.delete("/api/sessions/<int:sid>")
def delete_session(sid):
    db().execute("DELETE FROM sessions WHERE id=?", (sid,))
    db().commit()
    return jsonify(ok=True)


# ---------- settings ----------
@app.get("/api/settings")
def read_settings():
    return jsonify(get_settings())


@app.put("/api/settings")
def save_settings():
    d = request.get_json(force=True)
    pref = d.get("preferred_time")
    if pref not in scheduler.START_MINUTES:
        raise ValueError("Pick a preferred study time.")
    db().execute("UPDATE settings SET name=?, course=?, daily_hours=?, preferred_time=?, session_minutes=?, break_minutes=? WHERE id=1",
                 (valid_text(d.get("name"), "Name"), str(d.get("course") or "")[:80], valid_num(d.get("daily_hours"), 1, 12, "Daily hours"),
                  pref, int(valid_num(d.get("session_minutes"), 20, 120, "Session length")), int(valid_num(d.get("break_minutes"), 5, 30, "Break length"))))
    db().commit()
    return jsonify(ok=True)


def bootstrap():
    if database.init_db():                 # first run: tables + sample student
        with app.app_context():
            regenerate(7)


bootstrap()

if __name__ == "__main__":
    app.run(debug=True)

"""
scheduler.py - the rule-based "AI" of StudyPilot AI.

This is a transparent, rule-based scheduling algorithm (no external AI model).
It is "intelligent" because it weighs several factors and adapts every day.

STEP 1  PRIORITY SCORE (0 to 1) for each subject
    score = 0.40 * urgency + 0.25 * difficulty + 0.20 * pending + 0.15 * remaining
      urgency    = 1 / (1 + days_left / 7)      -> closer exam = bigger number
      difficulty = Easy 0.33, Medium 0.66, Hard 1.0
      pending    = pending topics / largest pending count among subjects
      remaining  = 1 - completion percentage   -> less finished = bigger number

STEP 2  HOW MANY SESSIONS PER DAY
    One session = `session_minutes` of study followed by `break_minutes` of rest.
    n = (available_minutes + break) // (session + break)   (so the total, breaks
    included, never exceeds the student's daily availability).

STEP 3  SHARE THE SESSIONS
    Every active subject gets 1 session (fairness). Remaining sessions are shared
    in proportion to the priority scores (largest-remainder rounding).
    If there are fewer sessions than subjects, only the top-scoring subjects get one.

STEP 4  ORDER AND TIMES
    Sessions are interleaved (A B C A B ...) so the same subject is not studied
    back-to-back, then placed from the preferred start time with breaks between.
    Scores are recalculated for every day, so as an exam approaches the plan shifts.
"""
from datetime import date, timedelta

DIFFICULTY = {"Easy": 1 / 3, "Medium": 2 / 3, "Hard": 1.0}
START_MINUTES = {"morning": 8 * 60, "afternoon": 13 * 60, "evening": 17 * 60, "night": 20 * 60}
WEIGHTS = {"urgency": 0.40, "difficulty": 0.25, "pending": 0.20, "remaining": 0.15}


def to_minutes(hhmm):
    h, m = hhmm.split(":")
    return int(h) * 60 + int(m)


def to_hhmm(minutes):
    return f"{minutes // 60:02d}:{minutes % 60:02d}"


def days_left(subject, day):
    return (date.fromisoformat(subject["exam_date"]) - day).days


def priority_score(subject, day, max_pending):
    """Combine the four factors into one number (see module docstring)."""
    urgency = 1 / (1 + max(days_left(subject, day), 0) / 7)
    difficulty = DIFFICULTY[subject["difficulty"]]
    pending = subject["pending"] / max_pending if max_pending else 0
    remaining = 1 - subject["progress"] / 100
    return round(WEIGHTS["urgency"] * urgency + WEIGHTS["difficulty"] * difficulty
                 + WEIGHTS["pending"] * pending + WEIGHTS["remaining"] * remaining, 3)


def active_subjects(subjects, day):
    """Subjects still worth studying on `day`: exam not passed and topics pending."""
    return [s for s in subjects if s["pending"] > 0 and days_left(s, day) > 0]


def rank_subjects(subjects, day):
    """Return active subjects sorted by priority (highest first)."""
    active = active_subjects(subjects, day)
    max_pending = max((s["pending"] for s in active), default=0)
    for s in active:
        s["score"] = priority_score(s, day, max_pending)
    return sorted(active, key=lambda s: -s["score"])


def allocate(ranked, n):
    """Split n sessions between subjects: 1 each first, then by score."""
    counts = {s["id"]: 0 for s in ranked}
    if n < len(ranked):
        for s in ranked[:n]:
            counts[s["id"]] = 1
        return counts
    for s in ranked:
        counts[s["id"]] = 1
    extra = n - len(ranked)
    total = sum(s["score"] for s in ranked)
    quota = {s["id"]: extra * s["score"] / total for s in ranked}
    for sid, q in quota.items():
        counts[sid] += int(q)
    leftover = extra - sum(int(q) for q in quota.values())
    for sid in sorted(quota, key=lambda k: quota[k] - int(quota[k]), reverse=True)[:leftover]:
        counts[sid] += 1
    return counts


def generate_plan(subjects, settings, start_date, days=7, done_today=0, earliest_today=None):
    """
    Build a list of session dicts for `days` days starting at `start_date`.
    done_today / earliest_today account for sessions already completed today.
    Each subject needs a 'queue' list of (topic_id, title) still to study.
    """
    sess, brk = settings["session_minutes"], settings["break_minutes"]
    plan = []
    cursors = {s["id"]: 0 for s in subjects}          # rotates through each subject's topics
    for d in range(days):
        day = start_date + timedelta(days=d)
        available = settings["daily_hours"] * 60
        start = START_MINUTES[settings["preferred_time"]]
        if d == 0:
            available -= done_today
            if earliest_today:
                start = max(start, earliest_today)
        n = int((available + brk) // (sess + brk))
        while n > 0 and start + n * sess + (n - 1) * brk > 24 * 60:   # stay inside the day
            n -= 1
        ranked = rank_subjects(subjects, day)
        if n <= 0 or not ranked:
            continue
        counts = allocate(ranked, n)
        order, left = [], dict(counts)
        while len(order) < n:                          # interleave subjects
            for s in ranked:
                if left[s["id"]] > 0:
                    order.append(s)
                    left[s["id"]] -= 1
        clock = start
        for i, s in enumerate(order):
            queue = s["queue"]
            if queue:
                topic_id, title = queue[cursors[s["id"]] % len(queue)]
                cursors[s["id"]] += 1
            else:
                topic_id, title = None, "Revision and practice"
            plan.append(dict(subject_id=s["id"], topic_id=topic_id, topic=title, date=day.isoformat(),
                             start_time=to_hhmm(clock), end_time=to_hhmm(clock + sess), minutes=sess, kind="study"))
            clock += sess
            if i < len(order) - 1:
                plan.append(dict(subject_id=None, topic_id=None, topic="Short break", date=day.isoformat(),
                                 start_time=to_hhmm(clock), end_time=to_hhmm(clock + brk), minutes=brk, kind="break"))
                clock += brk
    return plan


def recommend(subjects, today, streak, missed, done_today_minutes, settings):
    """Rule-based suggestions: each rule below checks a condition and adds a message."""
    recs = []
    ranked = rank_subjects(subjects, today)
    if ranked:
        top = ranked[0]
        recs.append(dict(kind="next", title=f"Study next: {top['name']}",
                         text=f"Highest priority ({top['score']}). Exam in {days_left(top, today)} days with "
                              f"{top['pending']} topics pending and {top['progress']}% done."))
    for s in ranked:
        left = days_left(s, today)
        if left <= 3 and s["progress"] < 80:
            recs.append(dict(kind="urgent", title=f"{s['name']} exam in {left} day{'s' if left != 1 else ''}",
                             text=f"Only {s['progress']}% complete. Put every free session into this subject."))
        elif left <= 7 and s["progress"] < 60:
            recs.append(dict(kind="warn", title=f"{s['name']} exam is approaching",
                             text=f"{left} days left and {s['pending']} topics pending. Start revising soon."))
    for s in ranked:
        if s["progress"] < 30 and s["difficulty"] == "Hard":
            recs.append(dict(kind="attention", title=f"{s['name']} needs more attention",
                             text="A hard subject with little progress. Break it into small topics and start with the basics."))
    if missed:
        recs.append(dict(kind="adjust", title=f"You missed {missed} session{'s' if missed != 1 else ''}",
                         text="Regenerate your timetable so the missed topics are rescheduled.", action="regen"))
    if streak >= 3:
        recs.append(dict(kind="tip", title=f"{streak}-day streak", text="Keep it going. Even one session today protects your streak."))
    elif streak == 0:
        recs.append(dict(kind="tip", title="Start a streak today", text="Finish one 50-minute session to begin a new streak."))
    if done_today_minutes >= settings["daily_hours"] * 60:
        recs.append(dict(kind="tip", title="Daily goal reached", text="Rest well. Sleep helps memory more than extra late-night study."))
    recs.append(dict(kind="tip", title="Study hard topics first",
                     text=f"Your {settings['preferred_time']} slot is set. Start with the toughest topic while your focus is fresh."))
    return recs

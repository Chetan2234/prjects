# StudyPilot AI

An intelligent study planner for college students. Flask + SQLite + vanilla JS + Chart.js.
The "AI" is a transparent, rule-based scheduling algorithm (no external model or API).

## Run locally
```bash
cd studypilot-ai
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000. The first run creates `studypilot.db` with a sample student.
To reset the demo data, stop the server and delete `studypilot.db`.
(Fonts and Chart.js load from the internet, so you need a connection for charts.)

## Folder structure
```
app.py          Flask routes + validation (JSON API under /api)
scheduler.py    Priority score, session allocation, timetable, recommendations
database.py     SQLite schema and sample data
templates/      index.html (single-page shell)
static/css/     style.css (dark navy theme)
static/js/      app.js (pages, charts, forms)
```

## How the scheduler works (see scheduler.py for details)
1. Score each subject: `0.40*urgency + 0.25*difficulty + 0.20*pending + 0.15*remaining`.
2. Daily sessions = `(hours*60 + break) // (session + break)`, so breaks never push past the available time.
3. Each active subject gets one session; extra sessions are shared in proportion to the scores.
4. Sessions are interleaved, placed from the preferred start time, and recalculated daily as exams get closer.

Completing a session marks its topic done, which updates progress, the dashboard and recommendations.

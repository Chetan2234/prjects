/* StudyPilot AI - frontend. One page, hash routing (#dashboard, #subjects ...),
   all data comes from the Flask JSON API under /api. */
const $ = (s, r = document) => r.querySelector(s);
const main = $('#main');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = n => String(n).padStart(2, '0');
const iso = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parse = s => new Date(s + 'T00:00');
const fmt = (s, o = { day: 'numeric', month: 'short' }) => parse(s).toLocaleDateString('en-IN', o);
const todayISO = () => iso(new Date());
const COLORS = ['#7c5cff', '#3b82f6', '#22d3ee', '#f472b6', '#fbbf24', '#34d399', '#fb923c'];
const color = id => COLORS[(id || 0) % COLORS.length];

async function api(url, method = 'GET', body) {
  const r = await fetch('/api' + url, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Something went wrong. Try again.');
  return d;
}
function toast(msg, bad) {
  const t = $('#toast'); t.textContent = msg; t.className = 'show' + (bad ? ' bad' : '');
  clearTimeout(toast.t); toast.t = setTimeout(() => t.className = '', 2800);
}
const charts = {};
function chart(id, cfg) {
  if (typeof Chart === 'undefined') { $('#' + id).replaceWith(Object.assign(document.createElement('p'), { className: 'muted', textContent: 'Charts need internet access to load Chart.js.' })); return; }
  charts[id]?.destroy(); charts[id] = new Chart($('#' + id), cfg);
}
if (typeof Chart !== 'undefined') { Chart.defaults.color = '#8d97c4'; Chart.defaults.borderColor = '#222b55'; Chart.defaults.font.family = 'Manrope, sans-serif'; }

const PAGES = [['dashboard', 'Dashboard'], ['subjects', 'Subjects'], ['planner', 'AI Planner'], ['timetable', 'Timetable'], ['progress', 'Progress'], ['insights', 'Recommendations'], ['settings', 'Settings']];
const ICON = {
  dashboard: '<path d="M3 3h7v9H3zM14 3h7v5h-7zM14 12h7v9h-7zM3 16h7v5H3z"/>',
  subjects: '<path d="M4 19V5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2zM8 7h7"/>',
  planner: '<path d="M12 3l1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8zM19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>',
  timetable: '<path d="M3 5h18v16H3zM3 10h18M8 3v4M16 3v4"/>',
  progress: '<path d="M3 20h18M6 16v-5M11 16V6M16 16v-8"/>',
  insights: '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-4 10.5c.7.7 1 1.5 1 2.5h6c0-1 .3-1.8 1-2.5A6 6 0 0 0 12 3z"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>'
};
$('#nav').innerHTML = PAGES.map(([k, l]) => `<a href="#${k}" data-p="${k}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${ICON[k]}</svg><span>${l}</span></a>`).join('');

const head = (title, sub = '', actions = '') => `<div class="head"><div><h1>${title}</h1><p class="muted">${sub}</p></div><div>${actions}</div></div>`;
const bar = p => `<div class="bar"><i style="width:${p}%"></i></div>`;
const empty = (msg, link = '') => `<div class="empty">${msg}${link}</div>`;

/* ---------- reusable pieces ---------- */
function sessionRow(s) {
  return `<label class="row ${s.done ? 'done' : ''}"><input type="checkbox" data-act="toggle" data-id="${s.id}" ${s.done ? 'checked' : ''}>
  <span class="time">${s.start_time}–${s.end_time}</span><span class="dot" style="background:${color(s.subject_id)}"></span>
  <b>${esc(s.subject_name)}</b><span class="muted">${esc(s.topic)}</span></label>`;
}
const recCard = r => `<div class="rec ${r.kind}"><b>${esc(r.title)}</b><p>${esc(r.text)}</p>${r.action === 'regen' ? '<button class="sm" data-act="regen">Regenerate timetable</button>' : ''}</div>`;
const statCard = (label, value, cls = '') => `<div class="card stat ${cls}"><span class="muted">${label}</span><b>${value}</b></div>`;
function weeklyChart(id, daily) {
  chart(id, { type: 'bar', data: { labels: daily.map(d => fmt(d.date, { weekday: 'short' })), datasets: [
    { label: 'Studied (h)', data: daily.map(d => +(d.done / 60).toFixed(1)), backgroundColor: '#7c5cff', borderRadius: 8 },
    { label: 'Planned (h)', data: daily.map(d => +(d.planned / 60).toFixed(1)), type: 'line', borderColor: '#3b82f6', tension: .35, pointRadius: 3 }] },
    options: { maintainAspectRatio: false, scales: { y: { beginAtZero: true } } } });
}

/* ---------- views ---------- */
async function dashboard() {
  const [d, recs] = await Promise.all([api('/dashboard'), api('/recommendations')]);
  const hr = new Date().getHours(), greet = hr < 12 ? 'morning' : hr < 17 ? 'afternoon' : 'evening';
  const study = d.today.filter(s => s.kind === 'study');
  main.innerHTML = head(`Good ${greet}, ${esc(d.name.split(' ')[0])}`, 'Here is your study plan for today.', '<a class="btn" href="#planner">Plan my week</a>') + `
  <div class="grid g4">${statCard('Total study hours', d.total_hours + ' h', 'hero')}${statCard('Completed tasks', d.completed)}${statCard('Pending tasks', d.pending)}
  <div class="card stat"><div class="ring" style="--p:${d.progress}"><i>${d.progress}%</i></div><span class="muted">Overall progress</span><b>${d.progress}%</b></div></div>
  <div class="grid g2" style="margin-top:16px">
    <div class="card"><h3>Today's schedule</h3>${study.length ? study.map(sessionRow).join('') : empty('Nothing scheduled today.', ' <a href="#planner"><u>Generate a plan</u></a>')}</div>
    <div class="card"><h3>Upcoming examinations</h3>${d.exams.length ? d.exams.map(e => `<div class="row" style="cursor:default"><div style="flex:1"><b>${esc(e.name)}</b> <span class="badge ${e.difficulty}">${e.difficulty}</span>${bar(e.progress)}<small>${e.progress}% ready</small></div>
      <div style="text-align:right"><b>${fmt(e.exam_date)}</b><br><small>${e.days_left} days</small></div></div>`).join('') : empty('No exams yet.', ' <a href="#subjects"><u>Add a subject</u></a>')}</div>
    <div class="card"><h3>Weekly productivity</h3><div class="chartbox"><canvas id="c1"></canvas></div></div>
    <div class="card"><h3>Smart recommendations</h3>${recs.slice(0, 3).map(recCard).join('')}<a href="#insights" class="muted"><u>See all</u></a></div></div>`;
  weeklyChart('c1', d.weekly);
}

async function subjects() {
  const subs = await api('/subjects');
  const min = iso(new Date(Date.now() + 864e5));
  main.innerHTML = head('Subjects', 'Add subjects, break them into topics and track progress.') + `
  <form class="card form" data-form="addSubject" style="margin-bottom:16px">
    <label class="f">Subject name<input name="name" required maxlength="60" placeholder="e.g. Computer Networks"></label>
    <label class="f">Difficulty<select name="difficulty"><option>Easy</option><option selected>Medium</option><option>Hard</option></select></label>
    <label class="f">Exam date<input type="date" name="exam_date" min="${min}" required></label><button>Add subject</button></form>
  <div class="grid g2">${subs.map(s => `<div class="card"><div class="top"><div><h3>${esc(s.name)}</h3>
    <span class="badge ${s.difficulty}">${s.difficulty}</span> <small>Exam ${fmt(s.exam_date)} · ${s.days_left} days left</small></div>
    <button class="ghost danger sm" data-act="delSubject" data-id="${s.id}">Remove</button></div>
    ${bar(s.progress)}<small>${s.done} of ${s.total} topics done · ${s.progress}%</small>
    <ul class="topics">${s.topics.map(t => `<li><label><input type="checkbox" data-act="toggleTopic" data-id="${t.id}" ${t.done ? 'checked' : ''}>${esc(t.title)}</label><button class="x" data-act="delTopic" data-id="${t.id}" aria-label="Delete topic">×</button></li>`).join('')}</ul>
    <form class="inline" data-form="addTopic" data-id="${s.id}"><input name="title" required maxlength="80" placeholder="Add a topic"><button class="sm">Add</button></form></div>`).join('') || empty('No subjects yet. Add your first one above.')}</div>`;
}

async function planner() {
  const [subs, st] = await Promise.all([api('/subjects'), api('/settings')]);
  if (!subs.length) { main.innerHTML = head('AI Study Planner') + `<div class="card">${empty('Add subjects first.', ' <a href="#subjects"><u>Go to Subjects</u></a>')}</div>`; return; }
  main.innerHTML = head('AI Study Planner', 'Confirm your details and StudyPilot builds a timetable using a priority score.') + `
  <form class="card" data-form="planner"><h3>Your subjects</h3><div class="scroll"><table><tr><th>Subject</th><th>Difficulty</th><th>Exam date</th><th>Pending topics</th></tr>
  ${subs.map(s => `<tr data-sid="${s.id}"><td><b>${esc(s.name)}</b></td><td><select name="difficulty">${['Easy', 'Medium', 'Hard'].map(x => `<option ${x === s.difficulty ? 'selected' : ''}>${x}</option>`).join('')}</select></td>
  <td><input type="date" name="exam_date" value="${s.exam_date}" required></td><td><input type="number" name="pending" min="0" max="99" value="${s.pending}" required></td></tr>`).join('')}</table></div>
  <div class="form" style="margin-top:18px"><label class="f">Available hours per day<input type="number" name="hours" min="1" max="12" step="0.5" value="${st.daily_hours}" required></label>
  <label class="f">Preferred study time<select name="preferred">${[['morning', 'Morning (8:00)'], ['afternoon', 'Afternoon (13:00)'], ['evening', 'Evening (17:00)'], ['night', 'Night (20:00)']].map(([v, l]) => `<option value="${v}" ${v === st.preferred_time ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
  <label class="f">Plan length<select name="days"><option value="7">7 days</option><option value="14">14 days</option></select></label><button>Generate timetable</button></div></form>
  <div id="result"></div>`;
}

const tt = { mode: 'week', anchor: new Date() };
async function timetable() {
  const a = new Date(tt.anchor), week = tt.mode === 'week';
  if (week) a.setDate(a.getDate() - ((a.getDay() + 6) % 7));
  const days = Array.from({ length: week ? 7 : 1 }, (_, i) => { const d = new Date(a); d.setDate(d.getDate() + i); return iso(d); });
  const [list, upcoming] = await Promise.all([api(`/sessions?start=${days[0]}&end=${days.at(-1)}`),
    api(`/sessions?start=${todayISO()}&end=${iso(new Date(Date.now() + 14 * 864e5))}`)]);
  const next = upcoming.filter(s => s.kind === 'study' && !s.done).slice(0, 5), t = todayISO();
  const card = s => s.kind === 'break' ? `<div class="brk">☕ ${s.minutes} min break</div>` :
    `<div class="ses ${s.done ? 'done' : ''} ${!s.done && s.date < t ? 'missed' : ''}" style="border-left-color:${color(s.subject_id)}">
    <div class="t"><b>${esc(s.subject_name)}</b><input type="checkbox" data-act="toggle" data-id="${s.id}" ${s.done ? 'checked' : ''} aria-label="Mark completed"></div>
    <small>${s.start_time}–${s.end_time} · ${esc(s.topic)}</small>
    <div class="acts"><button class="ghost sm" data-act="editSession" data-id="${s.id}">Edit</button><button class="ghost sm danger" data-act="delSession" data-id="${s.id}">Delete</button></div></div>`;
  main.innerHTML = head('Timetable', week ? `${fmt(days[0])} – ${fmt(days[6])}` : fmt(days[0], { weekday: 'long', day: 'numeric', month: 'long' }),
    `<span class="seg"><button class="${week ? 'on' : ''}" data-act="mode" data-id="week">Week</button><button class="${week ? '' : 'on'}" data-act="mode" data-id="day">Day</button></span>
     <button class="ghost" data-act="nav" data-id="-1">‹</button><button class="ghost" data-act="nav" data-id="0">Today</button><button class="ghost" data-act="nav" data-id="1">›</button>
     <button class="ghost" data-act="addSession">+ Session</button><button data-act="regen">Regenerate</button>`) +
    `<div class="week ${week ? '' : 'day'}">${days.map(d => `<div class="col ${d === t ? 'today' : ''}"><h4>${fmt(d, { weekday: 'short', day: 'numeric', month: 'short' })}</h4>
    ${list.filter(s => s.date === d).map(card).join('') || '<div class="brk">Free day</div>'}</div>`).join('')}</div>
    <div class="card" style="margin-top:16px"><h3>Upcoming study tasks</h3>${next.length ? next.map(s => `<div class="row" style="cursor:default"><span class="time">${fmt(s.date, { weekday: 'short', day: 'numeric' })} ${s.start_time}</span><span class="dot" style="background:${color(s.subject_id)}"></span><b>${esc(s.subject_name)}</b><span class="muted">${esc(s.topic)}</span></div>`).join('') : empty('All caught up.')}</div>`;
}

async function progress() {
  const p = await api('/progress');
  main.innerHTML = head('Progress', 'See how your study time and topics are adding up.') + `
  <div class="grid g4">${statCard('Today', p.today_hours + ' h')}${statCard('This week', p.week_hours + ' h')}${statCard('Topics completed', `${p.topics_done}/${p.topics_total}`)}${statCard('Study streak', p.streak + (p.streak === 1 ? ' day' : ' days'), 'hero')}</div>
  <div class="grid g2" style="margin-top:16px"><div class="card"><h3>Daily study hours</h3><div class="chartbox"><canvas id="c1"></canvas></div></div>
  <div class="card"><h3>Subject-wise progress</h3><div class="chartbox"><canvas id="c2"></canvas></div></div></div>
  <div class="card" style="margin-top:16px"><h3>Topics per subject</h3>${p.subjects.map(s => `<div style="margin-bottom:12px"><b>${esc(s.name)}</b> <small>${s.done}/${s.total} topics · ${s.progress}%</small>${bar(s.progress)}</div>`).join('') || empty('No subjects yet.')}</div>`;
  weeklyChart('c1', p.daily);
  chart('c2', { type: 'bar', data: { labels: p.subjects.map(s => s.name), datasets: [{ data: p.subjects.map(s => s.progress), backgroundColor: p.subjects.map((_, i) => COLORS[i % 7]), borderRadius: 8 }] },
    options: { indexAxis: 'y', maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { max: 100, beginAtZero: true } } } });
}

async function insights() {
  const recs = await api('/recommendations');
  main.innerHTML = head('Smart recommendations', 'Rule-based suggestions from your exams, progress and missed sessions.') + `<div class="card">${recs.map(recCard).join('')}</div>`;
}

async function settings() {
  const s = await api('/settings');
  main.innerHTML = head('Settings', 'Update your profile and study preferences.') + `
  <form class="card form" data-form="settings"><label class="f">Name<input name="name" value="${esc(s.name)}" required maxlength="60"></label>
  <label class="f">Course<input name="course" value="${esc(s.course)}" maxlength="80"></label>
  <label class="f">Available hours per day<input type="number" name="daily_hours" min="1" max="12" step="0.5" value="${s.daily_hours}" required></label>
  <label class="f">Preferred study time<select name="preferred_time">${['morning', 'afternoon', 'evening', 'night'].map(v => `<option ${v === s.preferred_time ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
  <label class="f">Session length (min)<input type="number" name="session_minutes" min="20" max="120" value="${s.session_minutes}" required></label>
  <label class="f">Break length (min)<input type="number" name="break_minutes" min="5" max="30" value="${s.break_minutes}" required></label><button>Save changes</button></form>`;
}

/* ---------- session dialog (add / edit) ---------- */
async function sessionDialog(id) {
  const subs = await api('/subjects');
  if (!subs.length) return toast('Add a subject first.', true);
  let s = { subject_id: subs[0].id, topic: '', date: todayISO(), start_time: '17:00', minutes: 50 };
  if (id) s = (await api(`/sessions?start=2000-01-01&end=2100-01-01`)).find(x => x.id == id) || s;
  const dlg = $('#dlg');
  dlg.innerHTML = `<form data-form="session" data-id="${id || ''}"><h3>${id ? 'Edit' : 'Add'} study session</h3><div class="form">
  <label class="f" style="grid-column:1/-1">Subject<select name="subject_id">${subs.map(x => `<option value="${x.id}" ${x.id == s.subject_id ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></label>
  <label class="f" style="grid-column:1/-1">Topic<input name="topic" value="${esc(s.topic)}" maxlength="80" placeholder="What will you study?"></label>
  <label class="f">Date<input type="date" name="date" value="${s.date}" required></label><label class="f">Start<input type="time" name="start_time" value="${s.start_time}" required></label>
  <label class="f">Minutes<input type="number" name="minutes" min="10" max="240" value="${s.minutes}" required></label></div>
  <div class="actions"><button type="button" class="ghost" data-act="closeDlg">Cancel</button><button>Save</button></div></form>`;
  dlg.showModal();
}

/* ---------- events ---------- */
const refresh = () => route();
const actions = {
  async toggle(el) { await api(`/sessions/${el.dataset.id}`, 'PATCH', { done: el.checked }); toast(el.checked ? 'Session completed' : 'Marked as pending'); refresh(); },
  async delSession(el) { if (confirm('Delete this session?')) { await api(`/sessions/${el.dataset.id}`, 'DELETE'); toast('Session deleted'); refresh(); } },
  editSession: el => sessionDialog(el.dataset.id), addSession: () => sessionDialog(),
  closeDlg: () => $('#dlg').close(),
  async regen() { const r = await api('/regenerate', 'POST'); toast(`Timetable regenerated: ${r.sessions} sessions`); refresh(); },
  async delSubject(el) { if (confirm('Remove this subject and its topics?')) { await api(`/subjects/${el.dataset.id}`, 'DELETE'); toast('Subject removed'); refresh(); } },
  async toggleTopic(el) { await api(`/topics/${el.dataset.id}`, 'PATCH', { done: el.checked }); refresh(); },
  async delTopic(el) { await api(`/topics/${el.dataset.id}`, 'DELETE'); refresh(); },
  mode(el) { tt.mode = el.dataset.id; refresh(); },
  nav(el) { const n = +el.dataset.id; if (!n) tt.anchor = new Date(); else tt.anchor.setDate(tt.anchor.getDate() + n * (tt.mode === 'week' ? 7 : 1)); refresh(); }
};
const forms = {
  async addSubject(f) { await api('/subjects', 'POST', Object.fromEntries(new FormData(f))); toast('Subject added'); refresh(); },
  async addTopic(f) { await api(`/subjects/${f.dataset.id}/topics`, 'POST', Object.fromEntries(new FormData(f))); refresh(); },
  async session(f) {
    const body = Object.fromEntries(new FormData(f)); body.subject_id = +body.subject_id;
    await api(f.dataset.id ? `/sessions/${f.dataset.id}` : '/sessions', f.dataset.id ? 'PATCH' : 'POST', body);
    $('#dlg').close(); toast('Session saved'); refresh();
  },
  async settings(f) { await api('/settings', 'PUT', Object.fromEntries(new FormData(f))); toast('Settings saved'); loadWho(); },
  async planner(f) {
    const fd = Object.fromEntries(new FormData(f));
    const subjects = [...f.querySelectorAll('tr[data-sid]')].map(tr => ({ id: +tr.dataset.sid, difficulty: tr.querySelector('[name=difficulty]').value, exam_date: tr.querySelector('[name=exam_date]').value, pending: tr.querySelector('[name=pending]').value }));
    const r = await api('/planner', 'POST', { hours: fd.hours, preferred: fd.preferred, days: fd.days, subjects });
    toast('Timetable generated');
    $('#result').innerHTML = `<div class="card" style="margin-top:16px"><h3>Priority ranking used for today</h3>
    <p class="muted" style="margin-bottom:12px">${r.sessions} study sessions were scheduled over ${r.days} days. Higher score = more study time.</p>
    ${r.ranking.map(s => `<div style="margin-bottom:10px"><b>${esc(s.name)}</b> <small>score ${s.score} · ${s.days_left} days left · ${s.pending} topics pending · ${s.difficulty}</small>${bar(Math.round(s.score * 100))}</div>`).join('') || empty('No active subjects to schedule.')}
    <a class="btn" href="#timetable">View timetable</a></div>`;
  }
};
document.addEventListener('click', async e => {
  const el = e.target.closest('[data-act]');
  if (!el || el.matches('input,select')) return;
  try { await actions[el.dataset.act](el); } catch (err) { toast(err.message, true); }
});
document.addEventListener('change', async e => {
  if (!e.target.matches('input[data-act]')) return;
  try { await actions[e.target.dataset.act](e.target); } catch (err) { toast(err.message, true); }
});
document.addEventListener('submit', async e => {
  const f = e.target.closest('form[data-form]'); if (!f) return;
  e.preventDefault();
  try { await forms[f.dataset.form](f); } catch (err) { toast(err.message, true); }
});

/* ---------- router ---------- */
const views = { dashboard, subjects, planner, timetable, progress, insights, settings };
async function route() {
  const p = views[(location.hash || '#dashboard').slice(1)] ? (location.hash || '#dashboard').slice(1) : 'dashboard';
  document.querySelectorAll('#nav a').forEach(a => a.classList.toggle('on', a.dataset.p === p));
  try { await views[p](); } catch (err) { main.innerHTML = `<div class="card">${esc(err.message)}</div>`; }
}
async function loadWho() { const s = await api('/settings'); $('#who').innerHTML = `<b>${esc(s.name)}</b><span>${esc(s.course)}</span>`; }
window.addEventListener('hashchange', route);
loadWho(); route();
